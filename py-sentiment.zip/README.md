# 
Team-members: Aapo Humina, Ville Salin

Doing app/plugin with python to analyze texts sentiment(positive, negative)

